use Dancer;
use JSON
#set serializer => 'XML';
set serializer => 'JSON'; #un-comment this for json format responses

my %users = (
        userA => {
            name => "Carlos",
        },
        userB => {
            name => "Andres",
        },
        userC => {
            name => "Bryan",
        },
    );
  
get '/' => sub{
    return {message => "First rest Web Service with Perl and Dancer"};
};

get '/users/:name' => sub {
    my $user = params->{name};
    return {name => "$user"};
};
 
get '/users' => sub{

    return \%users;
};

post '/users' => sub{
	my $data = {
        name => params->{name},
    };

	push(\%users, $data);
	return \%users;

};

put '/users/:name' => sub{
	if (params->{name}){
		session name => params->{name};
		redirect params->{/user}
	}
};


dance;
